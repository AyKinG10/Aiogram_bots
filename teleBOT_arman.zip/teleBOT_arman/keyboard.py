from aiogram.types import *
htl= ReplyKeyboardMarkup(resize_keyboard=True)
b3 = KeyboardButton('Комнатаны броньдау')
b5 = KeyboardButton('Біз жайлы')
b4 = KeyboardButton('Байланыс')
htl.insert(b4).add(b3).insert(b5)

clbbtn=InlineKeyboardMarkup(resize_keyboard=True)
button1=InlineKeyboardButton('Бронь жасау')

kb_floor = ReplyKeyboardMarkup(resize_keyboard=True)
ot1 = KeyboardButton(text='1')
ot2 = KeyboardButton(text='2')
ot3 = KeyboardButton(text='3')
ot4 = KeyboardButton(text='4')
ot5 = KeyboardButton(text='5')
kb_floor.add(ot1).add(ot2).insert(ot3).insert(ot4).add(ot5)

kb_first = ReplyKeyboardMarkup(resize_keyboard=True)
fl1 = KeyboardButton(text="LUX")
fl3 = KeyboardButton(text="Comfort")
fl4 = KeyboardButton(text="VIP")
fl7 = KeyboardButton(text="Back")
kb_first.add(fl1).add(fl3).insert(fl4).add(fl7)

kb_second = ReplyKeyboardMarkup(resize_keyboard=True)
sf1= KeyboardButton(text="LUX")
sf3 = KeyboardButton(text="Comfort")
sf4 = KeyboardButton(text="VIP")
sf7 = KeyboardButton(text="Back")
kb_second.add(sf1).add(sf3).insert(sf4).add(sf7)

kb_third = ReplyKeyboardMarkup(resize_keyboard=True)
trdf1= KeyboardButton(text="LUX")
trdf3 = KeyboardButton(text="Comfort")
trdf4 = KeyboardButton(text="VIP")
trdf7 = KeyboardButton(text="Back")
kb_second.add(trdf1).add(trdf3).insert(trdf4).add(trdf7)

kb_fourth = ReplyKeyboardMarkup(resize_keyboard=True)
ff1= KeyboardButton(text="LUX")
ff3 = KeyboardButton(text="Comfort")
ff4 = KeyboardButton(text="VIP")
ff7 = KeyboardButton(text="Back")
kb_second.add(ff1).add(ff3).insert(ff4).add(ff7)

kb_fifth = ReplyKeyboardMarkup(resize_keyboard=True)
fvf1= KeyboardButton(text="LUX")
fvf3 = KeyboardButton(text="Comfort")
fvf4 = KeyboardButton(text="VIP")
fvf7 = KeyboardButton(text="Back")
kb_second.add(fvf1).add(fvf3).insert(fvf4).add(fvf7)


