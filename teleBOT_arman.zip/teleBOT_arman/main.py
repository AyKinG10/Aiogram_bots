from aiogram import types,Dispatcher,executor,Bot
from keyboard import *
from token import TOKEN_API
from aiogram.dispatcher.filters import Text


bot = Bot(TOKEN_API)
dp = Dispatcher(bot)

start_message = """<em>Добрый день!Я телеграм бот гостиницы "RIXOS ALMATY",который расположен в городе Алматы</em><b>Выберите команды: </b>"""

about_us = """Добрый день!Я телеграм бот гостиницы "RIXOS ALMATY",который расположен в городе Алматы"""

back ="""Rixos Almaty Hotel — это роскошный пятизвездочный отель с элегантным дизайном, расположенный в Центральной Азии на пересечении улочек Кабанабай Батыр
 и Сейфуллина в самом сердце зеленого города Алматы. Несмотря на то, что этот потрясающий город уже не является столицей Казахстана, при первом же взгляде 
 на него становится ясно, что именно здесь сосредоточено все культурное и историческое наследие."""

async def on_startup(_):
    print('Бот запущен')

@dp.message_handler(commands=['start'])
async def start_command(message: types.Message):
    await bot.send_photo(chat_id=message.chat.id, photo="https://dynamic-media-cdn.tripadvisor.com/media/photo-o/03/b9/1c/ea/rixos-almaty.jpg?w=700&h=-1&s=1")
    await message.answer(text=start_message,
                         parse_mode="HTML",
                         reply_markup=htl)

@dp.message_handler(Text(equals="Байланыс"))
async def desc(message: types.Message):
    await bot.send_photo(chat_id=message.chat.id, photo="https://imageio.forbes.com/blogs-images/clareoconnor/files/2017/09/0828_forbes-logo_650x455.jpg?height=455&width=650&fit=bounds")
    await message.answer(text = about_us,
                         parse_mode="HTML")
    await bot.send_photo(chat_id=message.chat.id, photo="https://upload.wikimedia.org/wikipedia/ru/e/e9/IATA.png")
    await message.delete()

@dp.message_handler(Text(equals="Біз жайлы"))
async def buy_tickets(message:types.Message):
    await message.answer(text=back,
                         reply_markup = htl)
    await message.delete()

@dp.message_handler(Text(equals="Комнатаны броньдау"))
async def buy_tickets(message:types.Message):
    await message.answer(text='Қабатты таңдау:',
                         reply_markup = kb_floor)
    await message.delete()
@dp.message_handler(Text(equals="Back"))
async def go_back(message:types.Message):
    await message.answer(text='Керекті команданы таңдаңыз:',
                         reply_markup=htl)

@dp.message_handler(Text(equals="1"))
async def ala(message:types.Message):
    await message.answer(text='Қандай бөлмені таңдағыңыз келеді: ',
                         reply_markup=kb_first)
    await message.delete()

@dp.message_handler(Text(equals="LUX"))
async def desc(message: types.Message):
    await bot.send_photo(chat_id=message.chat.id, photo="https://hotels.sletat.ru/i/f/35928_30.jpg",
                         caption="""Бөлме саны:1
                         ㅤㅤㅤㅤㅤㅤㅤБөлме өлшемі:32 м^2
                         ㅤㅤㅤㅤㅤㅤㅤЖайлы төсектер(бағасы:8,9) - 94 адамның бағалауы
                         ㅤㅤㅤㅤㅤㅤㅤ1 кереуеті, балконы, спутниктік арналары мен 
                         ㅤㅤㅤㅤㅤㅤㅤхалаттары бар теледидары бар екі орынды бөлме.
                         ㅤㅤㅤㅤㅤㅤㅤБағасы: 180 000 тг""",
                         reply_markup=clbbtn

                        )
    await message.delete()

@dp.message_handler(Text(equals="Comfort"))
async def desc(message: types.Message):
    await bot.send_photo(chat_id=message.chat.id, photo="https://ic.pics.livejournal.com/nemihail/38873494/2507635/2507635_original.jpg",
                         caption="""Бөлме саны:1
                         ㅤㅤㅤㅤㅤㅤㅤБөлме өлшемі:25 м^2
                         ㅤㅤㅤㅤㅤㅤㅤ(бағасы:8,3) - 106 адамның бағалауы
                         ㅤㅤㅤㅤㅤㅤㅤ2 кісілік кереует, балконы,
                         ㅤㅤㅤㅤㅤㅤㅤхалаттары бар екі орынды бөлме.
                         ㅤㅤㅤㅤㅤㅤㅤБағасы: 120 000 тг""",
                         reply_markup=clbbtn
                        )

    await message.delete()

@dp.message_handler(Text(equals="VIP"))
async def desc(message: types.Message):
    await bot.send_photo(chat_id=message.chat.id, photo="https://hotels.sletat.ru/i/f/35928_1.jpg",
                         caption="""Бөлме саны:3
                         ㅤㅤㅤㅤㅤㅤㅤБөлме өлшемі: 150 м^2
                         ㅤㅤㅤㅤㅤㅤㅤ(бағасы:9.0) - 74 адамның бағалауы
                         ㅤㅤㅤㅤㅤㅤㅤ2 кісілік кереует x3, балконы,терасса, спутниктік арналары мен плазмалық 
                         ㅤㅤㅤㅤㅤㅤㅤ телевизоры х3, халаттары бар екі орынды бөлме.
                         ㅤㅤㅤㅤㅤㅤㅤБағасы: 600 000 тг""",
                         reply_markup=clbbtn
                        )
    await message.delete()

@dp.message_handler(Text(equals="2"))
async def nqz(message:types.Message):

    await message.answer(text='Қандай бөлмені таңдағыңыз келеді: ',
                         reply_markup=kb_second)
    await message.delete()


@dp.message_handler(Text(equals="3"))
async def sco(message:types.Message):

    await message.answer(text='Қандай бөлмені таңдағыңыз келеді: ',
                         reply_markup=kb_third)
    await message.delete()


@dp.message_handler(Text(equals="4"))
async def cit(message:types.Message):
    await message.answer(text='Қандай бөлмені таңдағыңыз келеді: ',
                         reply_markup=kb_fourth)
    await message.delete()

@dp.message_handler(Text(equals="5"))
async def cit(message:types.Message):
    await message.answer(text='Қандай бөлмені таңдағыңыз келеді: ',
                         reply_markup=kb_fifth)
    await message.delete()

@dp.callback_query_handler()
async def vote_callback(callback:types.CallbackQuery):
    if callback.data == 'Бронь жасау':
        return await callback.answer(text="Комната броньдалды,қосымша ақпаратты қоңырау шалып біле аласыз.")


if __name__ == '__main__':
    executor.start_polling(dp,on_startup=on_startup, skip_updates=True)