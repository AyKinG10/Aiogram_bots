from aiogram.types import ReplyKeyboardMarkup,KeyboardButton,InlineKeyboardMarkup,InlineKeyboardButton

kb_client = ReplyKeyboardMarkup(resize_keyboard=True)
b1=KeyboardButton('Бот_туралы📑')
b2=KeyboardButton('Хабарласу📧')
b3=KeyboardButton('Машиналар✅')
b4=KeyboardButton('Артқа')
kb_client.add(b3).add(b1).insert(b2).insert(b4)

kb_services = ReplyKeyboardMarkup(resize_keyboard=True)
btn1 = KeyboardButton('Қайырымдылық орталықтары')
btn2 = KeyboardButton('Дүкендер')
btn3=KeyboardButton('Артқа')
kb_services.add(btn1).add(btn2).insert(btn3)

kb_sale = ReplyKeyboardMarkup(resize_keyboard=True)
salebtn1 = KeyboardButton('Жеңілдіктер')
salebtn2 = KeyboardButton('Артқа')
kb_sale.add(salebtn1,salebtn2)

kb_status = ReplyKeyboardMarkup(resize_keyboard=True)
bt1 = KeyboardButton('Мүгедек жандарға')
bt2 = KeyboardButton('Жетім жандарға')
bt3 = KeyboardButton('Тұл-жетім жандарға')
bt4 = KeyboardButton('Көпбалалы отбасыларға')
bt5 = KeyboardButton('Артқа')

kb_status.add(bt1).add(bt2).add(bt3).add(bt4).add(bt5)

kb_shops1 = InlineKeyboardMarkup(resize_keyboard=True)
button1 = InlineKeyboardButton(text='Magnum🛒',callback_data='adress1')
button2 = InlineKeyboardButton(text='Small🛒',callback_data='adress2')
kb_shops1.add(button1).add(button2)

kb_shops2 = InlineKeyboardMarkup(resize_keyboard=True)
button3 = InlineKeyboardButton(text='FixPrice🛒',callback_data='adress3')
button4 = InlineKeyboardButton(text='Small🛒',callback_data='adress4')
kb_shops2.add(button3).add(button4)


kb_shops3 = InlineKeyboardMarkup(resize_keyboard=True)
button5 = InlineKeyboardButton(text='DosMart🛒',callback_data='adress5')
button6 = InlineKeyboardButton(text='GalMart🛒',callback_data='adress6')
kb_shops3.add(button5).add(button6)

kb_shops4 = InlineKeyboardMarkup(resize_keyboard=True)
button7 = InlineKeyboardButton(text='FixPrice🛒',callback_data='adress3')
button8 = InlineKeyboardButton(text='GalMart🛒',callback_data='adress6')
kb_shops4.add(button7).add(button8)

