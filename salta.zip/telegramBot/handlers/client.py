from aiogram import types, Dispatcher
from aiogram.dispatcher.filters import Text
from aiogram.dispatcher.filters.state import StatesGroup, State
from aiogram.dispatcher import FSMContext
from create_bot import dp, bot
from keyboards import kb_start,kb_cities, kb_vac,ikb
from data_base import city_db



# @dp.message_handler(commands=['start','help'])

async def command_start(message: types.Message):
    await bot.send_message(message.from_user.id, 'Сәлеметсізбе,біздің ботқа қош келдіңіз!🤗', reply_markup=kb_start)
    await message.delete()



@dp.message_handler(Text(equals='Біз жайлы'))
async def komek_open_command(message: types.Message):
    await bot.send_photo(message.from_user.id, photo='https://thumbs.gfycat.com/MedicalReasonableBlackfly-mobile.jpg',
                         caption="""Барлықтарыға сәлем, бұл абитуриенттерге комек боты болып табылады.Бұл бот сізге универлер жайлы толық ақпаратты шығарып береді.""")


@dp.message_handler(Text(equals='Байланыс'))
async def komek_place_command(message: types.Message):
    await bot.send_photo(message.from_user.id,
                         photo='https://avatars.mds.yandex.net/i?id=8ff42d3c5d0864e979c2a5ee6e13cdfe058f4792-8259800-images-thumbs&n=13&exp=1',
                         caption="""<b>Егер сіздерде бот бойынша немесе басқа сұрақтар туындаса
Астыда көрсетілген байланыс түрлері арқылы бізбен байланыссаңыздар болады</b>
<b><em>Байланыс нөмірі:</em> +7 777 777 77 77</b>
<b><em>Gmail:</em> altynai@gmail.com</b>""", parse_mode='HTML')


@dp.message_handler(Text(equals='Артқа'))
async def back_command(message: types.Message):
    await message.reply('Керекті кнопканы басыңыз:', reply_markup=kb_start)


@dp.message_handler(Text(equals='Локациялар'))
async def komek_kyzmet_command(message: types.Message):
    await message.answer('Қала таңдаңыз', reply_markup=kb_cities)

@dp.message_handler(Text(equals='Almaty'))
async def komek_kyzmet_command_al(message: types.Message):
    await city_db.sql_read_al(message)
    await message.reply('Баға бере отырыңыз',reply_markup=ikb)

@dp.message_handler(Text(equals='Astana'))
async def komek_kyzmet_command_as(message: types.Message):
    await city_db.sql_read_as(message)
    await message.reply('Баға бере отырыңыз',reply_markup=ikb)

@dp.message_handler(Text(equals='Semey'))
async def komek_kyzmet_command_sm(message: types.Message):
    await city_db.sql_read_sm(message)
    await message.reply('Баға бере отырыңыз',reply_markup=ikb)

@dp.message_handler(Text(equals='Aqtau'))
async def komek_kyzmet_command_aq(message: types.Message):
    await city_db.sql_read_aq(message)
    await message.reply('Баға бере отырыңыз',reply_markup=ikb)


@dp.message_handler(Text(equals='Концультацияға жазылу'))
async def nas(message: types.Message):
    await message.reply('Аты-жөніңіз ?')
    await VacProfileGroup.name_and_sur.set()

@dp.callback_query_handler()
async def vote_callback(callback:types.CallbackQuery):
    if callback.data == 'like':
        return await callback.answer(show_alert=True,text="Сізге бұл локациядар ұнады!")
    await callback.answer(show_alert=True,text="Бұл локациялар сізді қанағаттандырмады!")
def register_handlers_client(dp: Dispatcher):
    dp.register_message_handler(command_start, commands=['start', 'help'])



