from keyboards.client_kb import kb_start,kb_cities,kb_vac,ikb
