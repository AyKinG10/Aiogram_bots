from aiogram.types import ReplyKeyboardMarkup,KeyboardButton,InlineKeyboardMarkup,InlineKeyboardButton

kb_start = ReplyKeyboardMarkup(resize_keyboard=True)
b1 = KeyboardButton('Біз жайлы')
b2 = KeyboardButton('Байланыс')
b3 = KeyboardButton('Локациялар')
b4 = KeyboardButton('Артқа')
kb_start.add(b3).add(b1).insert(b2).insert(b4)


kb_cities = ReplyKeyboardMarkup(resize_keyboard=True)
bt1 = KeyboardButton('Almaty')
bt2 = KeyboardButton('Astana')
bt3 = KeyboardButton('Semey')
bt4 = KeyboardButton('Aqtau')
kb_cities.add(bt1,bt2,bt3,bt4,b4)

kb_vac = ReplyKeyboardMarkup(resize_keyboard=True)
bt1 = KeyboardButton('Концультацияға жазылу')
bt2 = KeyboardButton('Артқа')
kb_vac.add(bt1,bt2)
ikb = InlineKeyboardMarkup(row_width=2)
ib1 = InlineKeyboardButton(text='❤', callback_data="like")
ib2 = InlineKeyboardButton(text='👎', callback_data="dislike")
ikb.add(ib1,ib2)
