import asyncio
from aiogram import types,Dispatcher,executor,Bot
from aiogram.contrib.fsm_storage.memory import MemoryStorage
from aiogram.types import KeyboardButton,ReplyKeyboardMarkup
from aiogram.utils.exceptions import BotBlocked
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters.state import State,StatesGroup
from keyboard import kb,kb_University,kb_Al,kb_Sm,kb_As,inkeyb
from token_api import Token
from aiogram.dispatcher.filters import Text

storage = MemoryStorage()
bot = Bot(Token)
dp = Dispatcher(bot,storage=storage)

class ProfileStatesGroup(StatesGroup):
    photo = State()
    name = State()
    age = State()
    description = State()

about_us = """<b>
Біздің мақсатымыз сіздерге бағыт-бағдар беру.
Бұл бот сізге пайдасын тигізеді деген үміттемін.</em>
<b>Сәттілік!!!</b>"""
contacts="""<b>Егер сіздерде бот бойынша немесе басқа сұрақтар туындаса
Астыда көрсетілген байланыс түрлері арқылы бізбен байланыссаңыздар болады</b>
<b><em>Байланыс нөмірі:</em> +7 777 777 77 77</b>
<b><em>Gmail:</em> altynai@gmail.com</b>"""
async def on_startup(_):
    print('Бот іске қосылды')

@dp.errors_handler(exception=BotBlocked)
async def error_bot_blocked(update: types.Update,exception: BotBlocked):
    print('Ботқа хат жолдау мүмкін емес, себебі біз бұғатталғанбыз')
    return True

def get_kb() -> ReplyKeyboardMarkup:
    kev= ReplyKeyboardMarkup(resize_keyboard=True)
    kev.add(KeyboardButton('/create'))
    return kev
def get_cancel_kb() -> ReplyKeyboardMarkup:
    keyb=ReplyKeyboardMarkup(resize_keyboard=True)
    keyb.add(KeyboardButton('/cancel'))
    return keyb


@dp.message_handler(commands=['start'])
async def start_command(message: types.Message):
    await message.answer(text="""<em><b>🙋Қош келдіңіз🙋‍♀ болашақ студент</b>!
    Алдымен өзіңіз жайлы айтыңыз🔻</em>""",
                         parse_mode="HTML",
                         reply_markup=get_kb())

@dp.message_handler(commands=['create'])
async def create_profile(message:types.Message) -> None:
    await message.reply('Өздіңіздің профиліңізді толтырайық.Алдымен фото-суретіңізді жіберіңіз:',reply_markup=get_cancel_kb())
    await ProfileStatesGroup.photo.set()

@dp.message_handler(commands=['cancel'],state='*')
async def cmd_end(message:types.Message,state: FSMContext)->None:
    if state is None:
        return
    await state.finish()
    await message.reply('Сіз профиль құруды бұғаттадыңыз',
                        reply_markup=kb)



@dp.message_handler(lambda message: not message.photo,state=ProfileStatesGroup.photo)
async def check_photo(message:types.Message):
    await message.reply('Бұл фото-сурет емес')

@dp.message_handler(content_types=['photo'],state=ProfileStatesGroup.photo)
async def load_photo(message: types.Message,state:FSMContext)->None:
    async with state.proxy() as data:
        data['photo'] = message.photo[0].file_id
    await message.reply('Есіміңіз кім болады ?')
    await ProfileStatesGroup.next()




@dp.message_handler(lambda message: not message.text,state=ProfileStatesGroup.name)
async def check_name(message:types.Message):
    await message.reply('Есіміңізді дұрыстап енгізіңіз !')

@dp.message_handler(state=ProfileStatesGroup.name)
async def enter_name(message:types.Message,state:FSMContext)->None:
    async with state.proxy() as data:
        data['name'] = message.text
    await message.reply('Жасыңыз қаншада ?')
    await ProfileStatesGroup.next()



@dp.message_handler(lambda message: not message.text.isdigit() or float(message.text) > 100,state=ProfileStatesGroup.age)
async def check_age(message:types.Message):
    await message.reply('Нақты жасыңызды енгізіңіз !')

@dp.message_handler(state=ProfileStatesGroup.age)
async def enter_age(message:types.Message,state:FSMContext)->None:
    async with state.proxy() as data:
        data['age'] = message.text
    await message.reply('Өзіңіз жайлы қысқаша айтсаңыз ?')
    await ProfileStatesGroup.next()


@dp.message_handler(state=ProfileStatesGroup.description)
async def enter_age(message:types.Message,state:FSMContext)->None:
    async with state.proxy() as data:
        data['description'] = message.text
        await bot.send_photo(chat_id=message.chat.id,
                             photo=data['photo'],
                             caption=f"{data['name']},{data['age']}\n{data['description']}")
        await message.reply('Сіздің анкета сәтті құрылды',reply_markup=kb)
        await state.finish()




@dp.message_handler(Text(equals="Профиль"))
async def city(message:types.Message,state:FSMContext):
    async with state.proxy() as data:
        data['description'] = message.text
        await bot.send_photo(chat_id=message.chat.id,
                             photo=data['photo'],
                             caption=f"{data['name']},{data['age']}\n{data['description']}")

@dp.message_handler(Text(equals="Біз жайлы"))
async def city(message:types.Message):
    await message.answer(text=about_us,
                         parse_mode="HTML")

@dp.message_handler(Text(equals="Байланыс"))
async def city(message:types.Message):
    await message.answer(text=contacts,
                         parse_mode="HTML")

@dp.message_handler(Text(equals="Университеттер"))
async def city(message:types.Message):
    await message.answer(text='Керекті қаланы таңдаңыз',
                         reply_markup=kb_University)

@dp.message_handler(Text(equals="Артқа"))
async def city(message:types.Message):
    await message.answer(text='Керекті қаланы таңдаңыз',
                         reply_markup=kb)






@dp.message_handler(Text(equals="Almaty"))
async def city(message:types.Message):
    await message.answer(text='Университетті таңдаңыз: ',
                         reply_markup=kb_Al)
@dp.message_handler(Text(equals="Semey"))
async def city(message:types.Message):
    await message.answer(text='Университетті таңдаңыз: ',
                         reply_markup=kb_Sm)
@dp.message_handler(Text(equals="Astana"))
async def city(message:types.Message):
    await message.answer(text='Университетті таңдаңыз: ',
                         reply_markup=kb_As)

@dp.message_handler(Text(equals="Narxoz University"))
async def city(message:types.Message):
    await bot.send_photo(message.chat.id,
                         photo="https://vernycapital.com/files/000/000/616/jXi58Zm.jpg",
                         caption="""<b>Narxoz University</b>
                         ㅤㅤㅤㅤ<b>Мамандықтар:</b><em>
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤГос.Управление
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤМеждународные отношения
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤСтатистика
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤЭкономика
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤСоциальная работа
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤСоциология
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤHR и бизнес планирование
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤРДиГб
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤDigital Management and design
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤПрикладная математика
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤDigital Engineering
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤФинансы
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤЭкология
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤМаркетинг</em>
                         <b>Ақылы негізде оқу</b>: <em>1 100 000 теңге </em>""",
                         parse_mode="HTML",
                         reply_markup=inkeyb)

@dp.message_handler(Text(equals="Satbaev University"))
async def city(message:types.Message):
    await bot.send_photo(message.chat.id,
                         photo="https://satbayev.university/file/2021/07/28/349bf7/_793-446.jpg",
                         caption="""<b>Satbaev University</b>
                         ㅤㅤㅤㅤ<b>Мамандықтар:</b><em>
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤDrilling Engineering
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤЖылу энергетикасы
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤРобототехника
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤЭнергетика
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤТау-кен инжинериясы
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤТелекомуникация
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤСәулет жіне дизайн
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤКөлік қызметтері
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤБизнес Инжиниринг
                         </em>
                         <b>Ақылы негізде оқу</b>: <em>800 000 теңге </em>""",
                         parse_mode="HTML")
@dp.message_handler(Text(equals="Shakarim University"))
async def city(message:types.Message):
    await bot.send_photo(message.chat.id,
                         photo="https://sun9-48.userapi.com/impf/c630527/v630527548/1813/Hs_bk5xpBIg.jpg?size=604x453&quality=96&sign=bd2f8dfe54bf4235954912c3e83332bd&type=album",
                         caption="""Shakarim University
                         ㅤㅤㅤㅤ<b>Мамандықтар:</b><em>
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤЖылу энергетикасы
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤРобототехника
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤЭнергетика
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤИновациалық технологиялар
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤТелекомуникация
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤПсихология
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤАғылшын пәні мұғалімі
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤМенеджмент
                         </em>
                         <b>Ақылы негізде оқу</b>: <em>500 000 теңге </em>""",
                         reply_markup=inkeyb)

@dp.message_handler(Text(equals="Semey Medical University"))
async def city(message:types.Message):
    await bot.send_photo(message.chat.id,
                         photo="https://i.ytimg.com/vi/oh41_lnueD0/maxresdefault.jpg",
                         caption="""Semey Medical University
                         ㅤㅤㅤㅤ<b>Мамандықтар:</b><em>
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤСтоматология
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤМейірген ісі
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤМейірген ісі(10 ай)
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤМейірген ісі(2,5 жыл)
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤҚоғамдық денсаулық сақтау
                         </em>
                          <b>Ақылы негізде оқу</b>: <em>800 000 теңге</em>""",
                         reply_markup=inkeyb)

@dp.message_handler(Text(equals="Narikbaev University"))
async def city(message:types.Message):
    await bot.send_photo(message.chat.id,
                         photo="https://visitnursultan.kz/upload/iblock/f75/wb79ik93kds716kcecbc7cvq7o8e737h.jpg",
                         caption="""Narikbaev University
                         ㅤㅤㅤㅤ<b>Мамандықтар:</b><em>
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤПсихология    
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤЭкономика
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤМенеджмент
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤЕсеп және аудит
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤҚаржы
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤТуризм 
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤАударма ісі
                         </em>
                         <b>Ақылы негізде оқу</b>: <em>1 000 000 теңге </em>""",
                         reply_markup=inkeyb)

@dp.message_handler(Text(equals="Eurasian University"))
async def city(message:types.Message):
    await bot.send_photo(message.chat.id,
                         photo="https://enu.kz/downloads/nauka/L.N.Gumilyov_Eurasian_National_University.JPG",
                         caption="""Eurasian University
                         ㅤㅤㅤㅤ<b>Мамандықтар:</b><em>
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤПедагогика және Психология    
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤӘлеуметтану
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤАрхеология және этнология
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤЕсеп және аудит
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤАвтоматтандыру және басқару
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤАқпараттық жүйелер 
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤТуризм
                         </em>
                         <b>Ақылы негізде оқу</b>: <em>1 000 000 теңге </em>""",
                         reply_markup=inkeyb)

@dp.message_handler(Text(equals="IT University"))
async def city(message:types.Message):
    await bot.send_photo(message.chat.id,
                         photo="https://dev.bi-group.org/upload/news-image/1568089150-09.jpeg",
                         caption="""IT University
                         ㅤㅤㅤㅤ<b>Мамандықтар:</b><em>
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤКомпьтерлік ғылымдар
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤПрограммалық инженерия
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤКиберқауіпсіздік
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤМедиа технологиялар
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤМатематика және есептеу техникасы
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤIT менеджмент
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤҮлкен деректер анализі
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤМенеджмент
                         </em>
                         <b>Ақылы негізде оқу</b>: <em>1 200 000 теңге </em>""",
                         reply_markup=inkeyb)


@dp.callback_query_handler()
async def callback_likes(callback: types.CallbackQuery) -> None:
    global is_voted
    global number
    if not is_voted:
        if callback.data =='Like':
            number+=1
            await callback.answer(show_alert=True,
                                  text="Бұл универ сізге ұнады",)
            is_voted=True
        await callback.answer(show_alert=True,
                              text="Бұл универ сізге ұнамады")
        is_voted=True
    await callback.answer(show_alert=True,
                          text='Сіз дауыс беріп қойғансыз!')


if __name__ == '__main__':
    executor.start_polling(dp,on_startup=on_startup,skip_updates=True)