from aiogram.types import KeyboardButton, ReplyKeyboardMarkup, InlineKeyboardMarkup, InlineKeyboardButton
kb = ReplyKeyboardMarkup(resize_keyboard=True)
b2 = KeyboardButton('Біз жайлы')
b3 = KeyboardButton('Университеттер')
b4 = KeyboardButton('Байланыс')
b5 = KeyboardButton('Профиль')
kb.insert(b5).insert(b2).insert(b3).add(b4)

inkeyb = InlineKeyboardMarkup(resize_keyboard=True)
ikb1 = InlineKeyboardButton('Ұнады',callback_data="Like")
ikb2 = InlineKeyboardButton('Ұнамады',callback_data="disLike")
inkeyb.add(ikb1,ikb2)

kb_University =ReplyKeyboardMarkup(resize_keyboard=True)
bp1=KeyboardButton(text='Almaty')
bp2=KeyboardButton(text='Astana')
bp3=KeyboardButton(text='Semey')
bu26=KeyboardButton(text="Артқа")
kb_University.add(bp1).insert(bp2).add(bp3).add(bu26)

kb_Al=ReplyKeyboardMarkup(resize_keyboard=True)
bu1=KeyboardButton(text="Narxoz University")
bu2=KeyboardButton(text="Satbaev University")
bu21=KeyboardButton(text="Артқа")
kb_Al.add(bu1,bu2,bu21)


kb_Sm=ReplyKeyboardMarkup(resize_keyboard=True)
bu7=KeyboardButton(text="Shakarim University")
bu9=KeyboardButton(text="Semey Medical University")
bu22=KeyboardButton(text="Артқа")
kb_Sm.add(bu7).add(bu9).add(bu22)


kb_As=ReplyKeyboardMarkup(resize_keyboard=True)
bu10=KeyboardButton(text="IT University")
bu12=KeyboardButton(text="Narikbaev University")
bu13=KeyboardButton(text="Eurasian University")
bu23=KeyboardButton(text="Артқа")
kb_As.add(bu10,bu12,bu13,bu23)




