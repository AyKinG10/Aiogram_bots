from aiogram import types,Dispatcher
from create_bot import dp,bot
from keyboards import kb_client
from data_base import sqlite_db


# @dp.message_handler(commands=['start','help'])

async def command_start(message : types.Message):
	try:
		await bot.send_message(message.from_user.id,'Сәлеметсізбе,біздің ботқа қош келдіңіз!🤗',reply_markup=kb_client)
		await message.delete()
	except:
		await message.reply('Botpen soilesu ushin ogan zhazynyz:\nhttps://t.me/komek_life_bot')

# @dp.message_handler(commands=['Бот_туралы'])
async def komek_open_command(message:types.Message):
	await bot.send_message(message.from_user.id,'Біз сізге Алматы қаласындағы қоғамдық қорлардың тізімін ұсынып,өзіңізге керек қызметте жұмыс жасаймыз!Бізді таңдағаныңызға рахмет!❤️')
	
# @dp.message_handler(commands=['Хабарласу'])
async def komek_place_command(message:types.Message):
	await bot.send_message(message.from_user.id,'Ғалымжан Дана-dana.galymzhan@narxoz.kz📲Қадырқұл Аружан-aruzhan.kadyrkul@narxoz📲')

@dp.message_handler(commands=['Қайырымдылық_орталықтары'])
async def komek_kyzmet_command(message:types.Message):
	await sqlite_db.sql_read(message)

def register_handlers_client(dp : Dispatcher):
	dp.register_message_handler(command_start,commands=['start','help'])
	dp.register_message_handler(komek_open_command,commands=['Бот_туралы'])
	dp.register_message_handler(komek_place_command,commands=['Хабарласу'])
	dp.register_message_handler(komek_kyzmet_command,commands=['Қайырымдылық_орталықтары'])



