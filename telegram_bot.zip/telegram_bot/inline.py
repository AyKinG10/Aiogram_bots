from aiogram import Bot,types
from aiogram.dispatcher import Dispatcher
from aiogram.utils import executor
import os 

from aiogram.types import InlineKeyboardMarkup,InlineKeyboardButton

bot = Bot(token=os.getenv('5964010831:AAGFFPNEzEyI8cSvib_ZFXdmQkD6wpWDaas'))
dp = Dispatcher(bot)

urlkb = InlineKeyboardMarkup(row_width=1)
urlButton = InlineKeyboardButton(text='Ссылка',url='https://egov.kz/cms/kk/articles/charity-foundation')
urlButton2 = InlineKeyboardButton(text='Ссылка2',url='https://narxoz.edu.kz/')
urlkb.add(urlButton,urlButton2)

@dp.message_handler(commands = 'Сілтемелер')
async def url_command(message : types.Message):
	await message.answer('Сілтеме:',reply_markup=urlkb)

executor.start_polling(dp,skip_updates=True)