from aiogram.types import ReplyKeyboardMarkup,KeyboardButton #,ReplyKeyboardRemove

b1=KeyboardButton('/Бот_туралы📑')
b2=KeyboardButton('/Хабарласу📧')
b3=KeyboardButton('/Қызметтер✅')
b4=KeyboardButton('/Қайырымдылық_орталықтары')



kb_client = ReplyKeyboardMarkup(resize_keyboard=True)
kb_client.add(b3).insert(b4).add(b1).insert(b2)
# kb_client.row()----barin bir qatarga qoiady