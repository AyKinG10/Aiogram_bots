from aiogram import Bot
from aiogram.dispatcher import Dispatcher
import os
from aiogram.contrib.fsm_storage.memory import MemoryStorage

storage = MemoryStorage()

bot = Bot(token="5964010831:AAGFFPNEzEyI8cSvib_ZFXdmQkD6wpWDaas")
dp = Dispatcher(bot,storage=storage)