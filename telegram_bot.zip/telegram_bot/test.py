from aiogram.utils import executor
from aiogram import Bot,types 
from aiogram.dispatcher import Dispatcher
import os 

bot = Bot(token=os.getenv('5964010831:AAGFFPNEzEyI8cSvib_ZFXdmQkD6wpWDaas'))
dp =Dispatcher(bot)

@dp.message_handler(commands=['start','help'])
async def command_start(message : types.Message):
	await message.reply('Жақсы')

@dp.message_handler(commands=['команда'])
async def echo(message : types.Message):
	await message.answer(message.text)

@dp.message_handler()
async def empty(message : types.Message):
	await message.answer('Бұндай команда жоқ!')
	await message.delete()


executor.start_polling(dp,skip_updates=True)