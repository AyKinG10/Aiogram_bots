from aiogram.types import KeyboardButton, ReplyKeyboardMarkup, InlineKeyboardMarkup, InlineKeyboardButton
kb = ReplyKeyboardMarkup(resize_keyboard=True)
b2 = KeyboardButton('Біз жайлы')
b3 = KeyboardButton('Университеттер')
b4 = KeyboardButton('Байланыс')

kb.insert(b2).insert(b3).add(b4)

kb_University =ReplyKeyboardMarkup(resize_keyboard=True)
bp1=KeyboardButton(text='Almaty')
bp2=KeyboardButton(text='Astana')
bp3=KeyboardButton(text='Semey')
bp4=KeyboardButton(text='Shymkent')
bp5=KeyboardButton(text='Oskemen')
bu26=KeyboardButton(text="Артқа")
kb_University.add(bp1).insert(bp2).add(bp3).insert(bp4).add(bp5).add(bu26)

kb_Al=ReplyKeyboardMarkup(resize_keyboard=True)
bu1=KeyboardButton(text="Narxoz University")
bu2=KeyboardButton(text="Satbaev University")
bu3=KeyboardButton(text="Kaspian University")
bu4=KeyboardButton(text="Turan University")
bu5=KeyboardButton(text="Al-Farabi University")
bu6=KeyboardButton(text="Asphendiarov University")
bu21=KeyboardButton(text="Артқа")
kb_Al.add(bu1,bu2,bu3,bu4,bu5,bu6,bu21)


kb_Sm=ReplyKeyboardMarkup(resize_keyboard=True)
bu7=KeyboardButton(text="Shakarim University")
bu8=KeyboardButton(text="AB University")
bu9=KeyboardButton(text="Semey Medical University")
bu22=KeyboardButton(text="Артқа")
kb_Sm.add(bu7).insert(bu8).add(bu9).add(bu22)


kb_As=ReplyKeyboardMarkup(resize_keyboard=True)
bu10=KeyboardButton(text="IT University")
bu11=KeyboardButton(text="Seyfullin University")
bu12=KeyboardButton(text="Narikbaev University")
bu13=KeyboardButton(text="Eurasian University")
bu23=KeyboardButton(text="Артқа")
kb_As.add(bu10,bu11,bu12,bu13,bu23)


kb_St=ReplyKeyboardMarkup(resize_keyboard=True)
bu14=KeyboardButton(text="Miras University")
bu15=KeyboardButton(text="SILKWAY University")
bu16=KeyboardButton(text="Auezov University")
bu17=KeyboardButton(text="Otyrar University")
bu24=KeyboardButton(text="Артқа")
kb_St.add(bu14,bu15,bu16,bu17,bu24)


kb_Os=ReplyKeyboardMarkup(resize_keyboard=True)
bu18=KeyboardButton(text="Serikbaev University")
bu19=KeyboardButton(text="Amanzholov University")
bu20=KeyboardButton(text="Kaz-American University")
bu25=KeyboardButton(text="Артқа")
kb_Os.add(bu14,bu15,bu16,bu25)



