from aiogram import types,Dispatcher,executor,Bot
from keyboard import kb,kb_University,kb_Al,kb_St,kb_Sm,kb_As,kb_Os
from token_api import Token
from aiogram.dispatcher.filters import Text


bot = Bot(Token)
dp = Dispatcher(bot)


about_us = """<b>Сәлем болашақ студент!</b><em>Бұл Абитуриенттерге көмек боты.
Бұл Бот сізге Қазақстандағы университеттер жайлы мәліметтер
шығарып береді.
Біздің мақсатымыз сіздерге бағыт-бағдар беру.
Бұл бот сізге пайдасын тигізеді деген үміттемін.</em>
<b>Сәттілік!!!</b>"""
contacts="""<b>Егер сіздерде бот бойынша немесе басқа сұрақтар туындаса
Астыда көрсетілген байланыс түрлері арқылы бізбен байланыссаңыздар болады</b>
<b><em>Байланыс нөмірі:</em> +7 777 777 77 77</b>
<b><em>Gmail:</em> altynai@gmail.com</b>"""
async def on_startup(_):
    print('Бот іске қосылды')


@dp.message_handler(commands=['start'])
async def start_command(message: types.Message):
    await message.answer(text="""<em><b>🙋Қош келдіңіз🙋‍♀ болашақ студент</b>!
    Керекті командаларды тізімнен таңдаңыз: 🔻</em>""",
                         parse_mode="HTML",
                         reply_markup=kb)

@dp.message_handler(Text(equals="Біз жайлы"))
async def city(message:types.Message):
    await message.answer(text=about_us,
                         parse_mode="HTML")

@dp.message_handler(Text(equals="Байланыс"))
async def city(message:types.Message):
    await message.answer(text=contacts,
                         parse_mode="HTML")

@dp.message_handler(Text(equals="Университеттер"))
async def city(message:types.Message):
    await message.answer(text='Керекті қаланы таңдаңыз',
                         reply_markup=kb_University)

@dp.message_handler(Text(equals="Артқа"))
async def city(message:types.Message):
    await message.answer(text='Керекті қаланы таңдаңыз',
                         reply_markup=kb)



@dp.message_handler(Text(equals="Almaty"))
async def city(message:types.Message):
    await message.answer(text='Университетті таңдаңыз: ',
                         reply_markup=kb_Al)
@dp.message_handler(Text(equals="Semey"))
async def city(message:types.Message):
    await message.answer(text='Университетті таңдаңыз: ',
                         reply_markup=kb_Sm)
@dp.message_handler(Text(equals="Astana"))
async def city(message:types.Message):
    await message.answer(text='Университетті таңдаңыз: ',
                         reply_markup=kb_As)
@dp.message_handler(Text(equals="Shymkent"))
async def city(message:types.Message):
    await message.answer(text='Университетті таңдаңыз: ',
                         reply_markup=kb_St)
@dp.message_handler(Text(equals="Oskemen"))
async def city(message:types.Message):
    await message.answer(text='Университетті таңдаңыз: ',
                         reply_markup=kb_Os)


@dp.message_handler(Text(equals="Narxoz University"))
async def city(message:types.Message):
    await bot.send_photo(message.chat.id,
                         photo="https://vernycapital.com/files/000/000/616/jXi58Zm.jpg",
                         caption="""<b>Narxoz University</b>
                         ㅤㅤㅤㅤ<b>Мамандықтар:</b><em>
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤГос.Управление
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤМеждународные отношения
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤСтатистика
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤЭкономика
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤСоциальная работа
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤСоциология
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤHR и бизнес планирование
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤРДиГб
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤDigital Management and design
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤПрикладная математика
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤDigital Engineering
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤФинансы
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤЭкология
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤМаркетинг</em>
                         <b>Ақылы негізде оқу</b>: <em>1 100 000 теңге </em>""",
                         parse_mode="HTML")

@dp.message_handler(Text(equals="Satbaev University"))
async def city(message:types.Message):
    await bot.send_photo(message.chat.id,
                         photo="https://satbayev.university/file/2021/07/28/349bf7/_793-446.jpg",
                         caption="""<b>Satbaev University</b>
                         ㅤㅤㅤㅤ<b>Мамандықтар:</b><em>
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤDrilling Engineering
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤЖылу энергетикасы
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤРобототехника
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤЭнергетика
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤТау-кен инжинериясы
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤТелекомуникация
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤСәулет жіне дизайн
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤКөлік қызметтері
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤБизнес Инжиниринг
                         </em>
                         <b>Ақылы негізде оқу</b>: <em>800 000 теңге </em>""",
                         parse_mode="HTML")
@dp.message_handler(Text(equals="Shakarim University"))
async def city(message:types.Message):
    await bot.send_photo(message.chat.id,
                         photo="https://sun9-48.userapi.com/impf/c630527/v630527548/1813/Hs_bk5xpBIg.jpg?size=604x453&quality=96&sign=bd2f8dfe54bf4235954912c3e83332bd&type=album",
                         caption="Shakarim University(demo)")

@dp.message_handler(Text(equals="Semey Medical University"))
async def city(message:types.Message):
    await bot.send_photo(message.chat.id,
                         photo="https://i.ytimg.com/vi/oh41_lnueD0/maxresdefault.jpg",
                         caption="Semey Medical University(demo)")

@dp.message_handler(Text(equals="Narikbaev University"))
async def city(message:types.Message):
    await bot.send_photo(message.chat.id,
                         photo="https://visitnursultan.kz/upload/iblock/f75/wb79ik93kds716kcecbc7cvq7o8e737h.jpg",
                         caption="Narikbaev University(demo)")

@dp.message_handler(Text(equals="Eurasian University"))
async def city(message:types.Message):
    await bot.send_photo(message.chat.id,
                         photo="https://enu.kz/downloads/nauka/L.N.Gumilyov_Eurasian_National_University.JPG",
                         caption="Eurasian University(demo)")

@dp.message_handler(Text(equals="IT University"))
async def city(message:types.Message):
    await bot.send_photo(message.chat.id,
                         photo="https://dev.bi-group.org/upload/news-image/1568089150-09.jpeg",
                         caption="IT University(demo)")

@dp.message_handler(Text(equals="SILKWAY University"))
async def city(message:types.Message):
    await bot.send_photo(message.chat.id,
                         photo="https://avatars.mds.yandex.net/get-altay/2366463/2a0000017042eb5e207e50316ea9149042cb/XXXL",
                         caption="SILKWAY University(demo)")

@dp.message_handler(Text(equals="Serikbaev University"))
async def city(message:types.Message):
    await bot.send_photo(message.chat.id,
                         photo="https://www.ektu.kz/media/533737/dsc_0035_.jpg",
                         caption="Serikbaev University(demo)")





if __name__ == '__main__':
    executor.start_polling(dp,on_startup=on_startup,skip_updates=True)