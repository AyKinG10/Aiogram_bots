from aiogram import types, Dispatcher
from aiogram.dispatcher.filters import Text
from aiogram.dispatcher.filters.state import StatesGroup, State
from aiogram.dispatcher import FSMContext
from create_bot import dp, bot
from keyboards import kb_client, kb_vac
from data_base import uni_db


class VacProfileGroup(StatesGroup):
    name_and_sur = State()
    univer = State()
    email = State()


# @dp.message_handler(commands=['start','help'])

async def command_start(message: types.Message):
    try:
        await bot.send_message(message.from_user.id, 'Сәлеметсізбе,біздің ботқа қош келдіңіз!🤗', reply_markup=kb_client)
        await message.delete()
    except:
        await message.reply('Botpen soilesu ushin ogan zhazynyz:\nhttps://t.me/komek_life_bot')


@dp.message_handler(Text(equals='Біз жайлы'))
async def komek_open_command(message: types.Message):
    await bot.send_photo(message.from_user.id, photo='https://thumbs.gfycat.com/MedicalReasonableBlackfly-mobile.jpg',
                         caption="""Барлықтарыға сәлем, бұл абитуриенттерге комек боты болып табылады.Бұл бот сізге универлер жайлы толық ақпаратты шығарып береді.""")


@dp.message_handler(Text(equals='Байланыс'))
async def komek_place_command(message: types.Message):
    await bot.send_photo(message.from_user.id,
                         photo='https://avatars.mds.yandex.net/i?id=8ff42d3c5d0864e979c2a5ee6e13cdfe058f4792-8259800-images-thumbs&n=13&exp=1',
                         caption="""<b>Егер сіздерде бот бойынша немесе басқа сұрақтар туындаса
Астыда көрсетілген байланыс түрлері арқылы бізбен байланыссаңыздар болады</b>
<b><em>Байланыс нөмірі:</em> +7 777 777 77 77</b>
<b><em>Gmail:</em> altynai@gmail.com</b>""", parse_mode='HTML')


@dp.message_handler(Text(equals='Артқа'))
async def back_command(message: types.Message):
    await message.reply('Керекті кнопканы басыңыз:', reply_markup=kb_client)


@dp.message_handler(Text(equals='Университеттер'))
async def komek_kyzmet_command(message: types.Message):
    await uni_db.sql_read(message)
    await message.answer('Концултация алу үшін батырманы басыңыз', reply_markup=kb_vac)


@dp.message_handler(Text(equals='Концультацияға жазылу'))
async def vacancy(message: types.Message):
    await message.reply('Аты-жөніңіз ?')
    await VacProfileGroup.name_and_sur.set()


@dp.message_handler(state=VacProfileGroup.name_and_sur)
async def printName(message: types.Message, state: FSMContext):
    async with state.proxy() as data:
        data['name_and_sur'] = message.text
    await message.reply('Кай мамандық бойынша концультация керек ?')
    await VacProfileGroup.next()


@dp.message_handler(state=VacProfileGroup.univer)
async def printVacName(message: types.Message, state: FSMContext):
    async with state.proxy() as data:
        data['univer'] = message.text
    await message.reply('Электронды поштаңызды жазыңыз: ')
    await VacProfileGroup.next()


@dp.message_handler(state=VacProfileGroup.email)
async def printVacforResume(message: types.Message, state: FSMContext):
    async with state.proxy() as data:
        data['email'] = message.text
        await bot.send_message(chat_id=message.chat.id,
                               text=f"Есімі:{data['name_and_sur']}\nКерек концультация: {data['univer']} мамандығы\nЭл.поштаңыз:{data['email']}")
    await message.answer('Сіздің өтінішіңіз сәтті қабылданды, сізге жақын арада хабарын береді ',
                         reply_markup=kb_client)
    await state.finish()


def register_handlers_client(dp: Dispatcher):
    dp.register_message_handler(command_start, commands=['start', 'help'])



