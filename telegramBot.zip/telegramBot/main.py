from aiogram import types,executor, Dispatcher,Bot
from config import TOKEN_API
from keybords import kb,ikb
bot = Bot(TOKEN_API)
dp = Dispatcher(bot)

HELP_COMMAND = """
<b>/help</b> - <em>Командалар тізімі</em>
<b>/start</b>- <em>Ботты іске асыру</em>
<b>/description</b> - <em>Бот жайлы ақпарат</em>
<b>/location_photo</b> - <em>Локациялар фотосы</em>
<b>/footer</b> - <em>,Байланыс жолдары</em>
"""
description = """<b>🔝🔝🔝Бұл Алматы қаласының көрікті, әсем жерлерін қарауға мүмкіндік беретін қосымша.🔝🔝🔝</b>"
                 "<em>Егер уақытыңызды қызықты өткізу үшін локация керек болса🤔🤔🤔,"
                 "осы ботқа жауап жазсаңыз болғаны.😉😉😉</em>"""""
footer = """Егерде сіз тағыда Алматы қаласының көркем жерлерін білетін болсаңыз,Осы байланыс нөмірлері мен пошталарға өтінім тастаңыз болады🔽
        🎩Saltanat@gmail.com🎩
        🔢+7707 707 77 77🔢
        """
async def on_startup(_):
    print('Бот запущен')


@dp.message_handler(commands=['start'])
async def start_command(message: types.Message):
    await message.answer(text="""<em>Біздің Телеграмм ботымызға <b>Қош келдіңіз</b>!
    Командалар тізімі пернетақтада берілген 🔽🔽🔽</em>
    """,
                         parse_mode="HTML",
                         reply_markup=kb)

@dp.message_handler(commands=['help'])
async def help_command(message: types.Message):
    await message.reply(text=HELP_COMMAND,
                        parse_mode="HTML",
                        reply_markup=kb)


@dp.message_handler(commands=['description'])
async def description_command(message: types.Message):
    await message.reply(text=description,
                        parse_mode="HTML")

@dp.message_handler(commands=['footer'])
async def description_command(message: types.Message):
    await message.reply(text=footer,
                        parse_mode="HTML")

@dp.message_handler(commands=['location_photo'])
async def send_image(message: types.Message):
    await bot.send_photo(message.chat.id,
                         photo="https://krot.info/uploads/posts/2021-12/1638439954_38-krot-info-p-kazakhstan-almati-dostoprimechatelnosti-kr-42.jpg",
                         caption="""Алғашқы Президент Саябағы,
                                    Орналасқан жері: https://go.2gis.com/6ozx9w""",
                         reply_markup=ikb
                         )
    await bot.send_photo(message.chat.id,
                         photo="https://tripplanet.ru/wp-content/uploads/asia/kazakhstan/alma-ata/kok-tobe-mountain-and-park.jpg",
                         caption="""Көк-төбе тауы,
                                    Орналасқан жері: https://go.2gis.com/knqdak""",
                         reply_markup=ikb
                         )
    await bot.send_photo(message.chat.id,
                         photo="https://tripplanet.ru/wp-content/uploads/asia/kazakhstan/alma-ata/big-almaty-lake.jpg",
                         caption="""Үлкен Алматы Көлі(БАО),
                                        Орналасқан жері: https://go.2gis.com/zi28q""",
                         reply_markup=ikb
                         )
    await bot.send_photo(message.chat.id,
                         photo="https://tripplanet.ru/wp-content/uploads/asia/kazakhstan/alma-ata/skating-rink-and-ski-resort-medeo.jpg",
                         caption="""Медеу кешені,
                                        Орналасқан жері: https://go.2gis.com/g79hu""",
                         reply_markup=ikb
                         )
    await bot.send_photo(message.chat.id,
                         photo="https://tripplanet.ru/wp-content/uploads/asia/kazakhstan/alma-ata/central-mosque-of-almaty.jpg",
                         caption="""Алматы орталық мешіті,
                                        Орналасқан жері: https://go.2gis.com/udqtwk""",
                         reply_markup=ikb
                         )
    await bot.send_photo(message.chat.id,
                         photo="https://tripplanet.ru/wp-content/uploads/asia/kazakhstan/alma-ata/monument-of-independence-of-kazakhstan-alma-ata.jpg",
                         caption="""Тәуелсіздік монументі,
                                    Орналасқан жері: https://go.2gis.com/v81nrs""",
                         reply_markup=ikb
                         )
    await bot.send_photo(message.chat.id,
                         photo="https://tripplanet.ru/wp-content/uploads/asia/kazakhstan/alma-ata/alma-ata-metro.jpg",
                         caption="""Алматы Метробекеті,
                                    Орналасқан жері: https://go.2gis.com/5qq0wy""",
                         reply_markup=ikb
                         )


@dp.callback_query_handler()
async def vote_callback(callback:types.CallbackQuery):
    if callback.data == 'like':
        return await callback.answer(text="Сізге бұл локация ұнады!")
    await callback.answer(text="Cізге бұл локация ұнамады !")

if __name__ == '__main__':
    executor.start_polling(dp,on_startup=on_startup,skip_updates=True)