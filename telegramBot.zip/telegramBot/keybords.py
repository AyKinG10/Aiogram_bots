from aiogram.types import KeyboardButton, ReplyKeyboardMarkup, InlineKeyboardMarkup, InlineKeyboardButton
kb = ReplyKeyboardMarkup(resize_keyboard=True)
b1 = KeyboardButton('/help')
b2 = KeyboardButton('/description')
b3 = KeyboardButton('/location_photo')
b4 = KeyboardButton('footer')

kb.add(b1).insert(b2).insert(b3).add(b4)
ikb = InlineKeyboardMarkup(row_width=2)
ib1 = InlineKeyboardButton(text='❤', callback_data="like")
ib2 = InlineKeyboardButton(text='👎', callback_data="dislike")
ikb.add(ib1,ib2)


