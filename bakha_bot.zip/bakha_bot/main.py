from aiogram import types,Dispatcher,executor,Bot
from keyboard import *
from TOKEN import TOKEN_API
from aiogram.dispatcher.filters import Text


bot = Bot(TOKEN_API)
dp = Dispatcher(bot)

start_message = """<em>Сәлем, бұл Қазақстандағы Алматы Автосалондар боты.Астыдағы командаларды таңдаңыз:</em>"""

about_us = """<b>Сәлем, бұл Алматы Автосалондар боты.Сізге автосалондар жайлы толық мәлімет беретін боламын.</b>"""

back ="""Егерде басқада Қазақстар аумағындағы автосалондар жайлы білетін болсаңыз
         autosalons_Kazakhstan@gmail.com почтасына жазып өтінім қалтырсаңыз болады."""

async def on_startup(_):
    print('Бот іске қосылды')

@dp.message_handler(commands=['start'])
async def start_command(message: types.Message):
    await bot.send_photo(chat_id=message.chat.id, photo="https://celes.club/uploads/posts/2022-06/1654653523_26-celes-club-p-oboi-na-telefon-ulibka-krasivie-30.jpg")
    await message.answer(text=start_message,
                         parse_mode="HTML",
                         reply_markup=mainbtn)

@dp.message_handler(Text(equals="Байланыс"))
async def connect(message: types.Message):
    await bot.send_photo(chat_id=message.chat.id, photo="https://yt3.ggpht.com/ytc/AMLnZu8EPSKDa5NMj9lAqHUPETW5H7Hppwii1ACN-Nbm=s900-c-k-c0x00ffffff-no-rj")
    await message.answer(text = back,
                         parse_mode="HTML")
    await message.delete()

@dp.message_handler(Text(equals="Біз жайлы"))
async def buy_about_us(message:types.Message):
    await message.answer(text=about_us,
                         reply_markup = mainbtn)
    await message.delete()

@dp.message_handler(Text(equals="Автосалондар"))
async def bron_room(message:types.Message):
    await message.answer(text='Маркаларды таңдаңыз:',
                         reply_markup = kb_salons)
    await message.delete()

@dp.message_handler(Text(equals="Back"))
async def back_commands(message:types.Message):
    await message.answer(text='Керекті команданы таңдаңыз:',
                         reply_markup=mainbtn)

@dp.message_handler(Text(equals="Alfa Motors(Chevrolet)"))
async def desc(message: types.Message):
    await bot.send_photo(chat_id=message.chat.id, photo="https://strg2.nm.kz/neofiles/serve-image/6294821d7b92ef0007ad1961/863x400/c1",
                         caption="""Адрес:
                         ㅤㅤㅤㅤㅤㅤㅤп. Иргели, трасса Алматы – Бишкек, здание 835
                         ㅤㅤㅤㅤㅤㅤㅤТелефон:
                         ㅤㅤㅤㅤㅤㅤㅤ+7 (727) 355 01 44, +7 (777) 099 22 22
                         ㅤㅤㅤㅤㅤㅤㅤОб автосалоне
                         ㅤㅤㅤㅤㅤㅤㅤАвтосалон в Алматы Alfa Motors (Альфа Моторс): продажа по цене от 4 190 000 ₸ до 33 000 000 ₸, 
                         ㅤㅤㅤㅤㅤㅤㅤ8 моделей в 19 комплектациях. Купить авто у официального дилера.""",
                         reply_markup=clbbtn

                        )
    await message.delete()

@dp.message_handler(Text(equals="Aster Auto LADA"))
async def desc(message: types.Message):
    await bot.send_photo(chat_id=message.chat.id, photo="https://strg1.nm.kz/neofiles/serve-image/6294823ef7e63100073287f0/863x400/c1",
                         caption="""Адрес:
                         ㅤㅤㅤㅤㅤㅤс. Бесагаш ул. Райымбека, 165
                         ㅤㅤㅤㅤㅤТелефон:
                         ㅤㅤㅤㅤㅤㅤㅤ+7 (700) 836 90 60 
                         ㅤㅤㅤㅤㅤОб автосалоне
                         ㅤㅤㅤㅤㅤㅤㅤАвтосалон в Алматы Aster Auto LADA (Астер Авто ЛАДА): продажа по цене от 4 890 000 ₸ до 10 900 000 ₸,
                         ㅤㅤㅤㅤㅤㅤㅤ15 моделей в 57 комплектациях. Купить авто у официального дилера.""",
                         reply_markup=clbbtn

                        )
    await message.delete()
@dp.message_handler(Text(equals="Audi Centre Almaty"))
async def desc(message: types.Message):
    await bot.send_photo(chat_id=message.chat.id, photo="https://strg1.nm.kz/neofiles/serve-image/6232fcf032d9260007a438c0/863x400/c1",
                         caption="""Адрес:
                         ㅤㅤㅤㅤㅤㅤㅤпр. Кульджинский тракт, 12/2
                         ㅤㅤㅤㅤㅤТелефон:
                         ㅤㅤㅤㅤㅤㅤㅤ+7 (727) 355 55 10, +7 (777) 715 55 08
                         ㅤㅤㅤㅤㅤОб автосалоне
                         ㅤㅤㅤㅤㅤㅤㅤАвтосалон Audi Centre Almaty (Ауди Центр Алматы): продажа по цене 47 500 000 ₸,
                         ㅤㅤㅤㅤㅤㅤㅤ1 модель в 1 комплектации. Купить авто у официального дилера.""",
                         reply_markup=clbbtn

                        )
    await message.delete()

@dp.message_handler(Text(equals="Bavaria Kuldzhinka"))
async def desc(message: types.Message):
    await bot.send_photo(chat_id=message.chat.id, photo="https://strg2.nm.kz/neofiles/serve-image/632ab3078d926600079b1df0/863x400/c1",
                         caption="""Адрес:
                         ㅤㅤㅤㅤㅤㅤㅤпр. Суюнбая, 151    
                         ㅤㅤㅤㅤㅤТелефон:
                         ㅤㅤㅤㅤㅤㅤㅤ+7 (727) 333 17 71, +7 (727) 297 96 13, +7 (727) 297 96 10, +7 (727) 297 96 66
                         ㅤㅤㅤㅤㅤОб автосалоне:
                         ㅤㅤㅤㅤㅤㅤㅤToyota Center Almaty — официальный дилер автомобилей Toyota в Казахстане.
                         ㅤㅤㅤㅤㅤㅤㅤВ 1995 году Toyota Center Almaty получил статус первой в Казахстане авторизованной сервисной станции «Toyota Motor Corporation» 
                         ㅤㅤㅤㅤㅤㅤㅤи с этого времени является полноправным членом сети авторизованных станций 
                         ㅤㅤㅤㅤㅤㅤㅤехнического обслуживания Toyota-TASS на территории СНГ.""",
                         reply_markup=clbbtn

                        )
    await message.delete()

@dp.callback_query_handler()
async def vote_callback(callback:types.CallbackQuery):
    if callback.data == 'Бронь жасау':
        return await callback.answer(text="Комната броньдалды,қосымша ақпаратты қоңырау шалып біле аласыз.")


if __name__ == '__main__':
    executor.start_polling(dp,on_startup=on_startup, skip_updates=True)