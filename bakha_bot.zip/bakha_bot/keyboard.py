from aiogram.types import *
mainbtn= ReplyKeyboardMarkup(resize_keyboard=True)
b3 = KeyboardButton('Комнатаны броньдау')
b5 = KeyboardButton('Біз жайлы')
b6 = KeyboardButton('Автосалондар')
b4 = KeyboardButton('Байланыс')
mainbtn.insert(b4).add(b3).insert(b5).add(b6)

clbbtn=InlineKeyboardMarkup(resize_keyboard=True)
button1=InlineKeyboardButton('Ұнады')

kb_salons = ReplyKeyboardMarkup(resize_keyboard=True)
bt1 = KeyboardButton(text='Alfa Motors(Chevrolet)')
bt2 = KeyboardButton(text='Aster Auto LADA')
bt3 = KeyboardButton(text='Audi Centre Almaty')
bt4 = KeyboardButton(text='Bavaria Kuldzhinka')
bt5 = KeyboardButton(text='Toyota Centre Almaty')
bt6 = KeyboardButton(text='Back')
kb_salons.add(bt1).add(bt2).insert(bt3).insert(bt4).add(bt5).insert(bt6)



