from aiogram import types,Dispatcher
from aiogram.dispatcher.filters import Text
from aiogram.dispatcher.filters.state import StatesGroup,State
from aiogram.dispatcher import FSMContext
from create_bot import dp,bot
from keyboards import kb_client,kb_vac
from data_base import sqlite_db

class VacProfileGroup(StatesGroup):
	name_and_sur = State()
	vacance = State()
	resume=State()

# @dp.message_handler(commands=['start','help'])

async def command_start(message : types.Message):
	try:
		await bot.send_message(message.from_user.id,'Сәлеметсізбе,біздің ботқа қош келдіңіз!🤗',reply_markup=kb_client)
		await message.delete()
	except:
		await message.reply('Botpen soilesu ushin ogan zhazynyz:\nhttps://t.me/komek_life_bot')

@dp.message_handler(Text(equals='Бот_туралы📑'))
async def komek_open_command(message:types.Message):
	await bot.send_photo(message.from_user.id, photo='https://yandex-images.clstorage.net/Cw9R74w15/c9506bzon7Vv/eV5yGtD6vcIFtTdvb0BtMgrQixNRfoSJmUoFt2QlcO_UZbjRNHGolwJ9o0xhGcTK9g1iIc9qb20FhIPIPArkPzgKtk7hDzgGJMB3718QTOfe4ZrW8TtVLbyPVNeh1aB6xRW9UBHkiVNS_SWa817D3IH7YKaorQu4UDHGuZiPFayb6mJJ1WlPYVNmZA1_MCwUKwHLVgG7VYjebUTC4iAmf0JFXwK0dvgDdaqWi_De85-QeWMUC61rGdPDBnjOv_QsWS3gqGTZ_rPzpmZc3jN8ZZjwmqQi21SYrY0nMmOSxR3jp_yDxVRIgKdbN-ujD-ONwHgzFIotKBoxcwdq7Q9GT0h-I7u2a_7zYyUlbJ2yvBRpk8skkIuG6JwO1ONz8QRu89cdUDZlq7LGq3Tb8GwzDeAIA1YLbbrqcfG1yz0sty2I_MKYdCt-4RM3Ba7d4Txm-yNLVIN6Notc_NWCAGKkP8JnLaGVxspxN8olOgEcQ99RK3N2e10IqCGBBrgtfIev-q5SeIVrXuNxxdRPbIBu56jiCLXhStYLvw7lsRMCtf2BBU9yVWb54scY11qRLJCuIaijRHoP-3ohQqeqXJ21jlivU2h3Sv7B0_QXnzxA7BX68eqGAGkGWV3td1IxAQWdM0bdY9d1ShIX-bUr023hn-OIw1RKrxr4M0DXSY4c9G0pnyBJhksdw1PUJ-_vkL6mKmP6FUNZlZidj0RQwZPlX2MXbIBHRquAl5sHeCO8o8wDKHFkKU-5uqAw54uNLob8S19jGNdYDyFQNSUtb7DO1BghirTDiibZrG03sGAQx16TZU6gNNWasLdqlPlCLMGv0brjRdtvaFlhQzbbT2y0TzkMgZiU6V1wQ8TEfP1S7je6Y4vFwxnnuI0-lzGDoLRMkxcekUQUalKUSxarwA2SX9NZcrXbXWj64eP22Cwe5D-JXxJYx4tv02In909-oC6luhOo5RCrVguN_9VTM',
						 caption="""Біз сізге Алматы қаласындағы IT мамандығы бойынша жұмыстарды көрсететін боламыз
						 Бізді таңдағаныңызға рахмет!❤""")
	
@dp.message_handler(Text(equals='Хабарласу📧'))
async def komek_place_command(message:types.Message):
	await bot.send_photo(message.from_user.id,photo='https://avatars.mds.yandex.net/i?id=8ff42d3c5d0864e979c2a5ee6e13cdfe058f4792-8259800-images-thumbs&n=13&exp=1',
						 caption="""Aliaskar Baqbergen""")

@dp.message_handler(Text(equals='Артқа'))
async def back_command(message:types.Message):
	await message.reply('Тізімнен керекті пунктті таңдаңыз:',reply_markup=kb_client)

@dp.message_handler(Text(equals='Вакансиялар✅'))
async def komek_kyzmet_command(message:types.Message):
	await sqlite_db.sql_read(message)
	await message.answer('Ұсыныс қалдыру үшін төмендегі батырманы басыңыз',reply_markup=kb_vac)

@dp.message_handler(Text(equals='Ұсыныс қалтыру'))
async def vacancy(message:types.Message):
	await message.reply('Аты-жөніңіз ?')
	await VacProfileGroup.name_and_sur.set()


@dp.message_handler(state=VacProfileGroup.name_and_sur)
async def printName(message:types.Message,state:FSMContext):
	async with state.proxy() as data:
		data['name_and_sur'] = message.text
	await message.reply('Вакансия атауын жазыңыз')
	await VacProfileGroup.next()

@dp.message_handler(state=VacProfileGroup.vacance)
async def printVacName(message:types.Message,state:FSMContext):
	async with state.proxy() as data:
		data['vacance'] = message.text
	await message.reply('Кішігірім өзіңіз жайлы айтып өтіңіз.')
	await VacProfileGroup.next()


@dp.message_handler(state=VacProfileGroup.resume)
async def printVacforResume(message:types.Message,state:FSMContext):
	async with state.proxy() as data:
		data['resume'] = message.text
		await bot.send_message(chat_id=message.chat.id,
							 text=f"Есімі:{data['name_and_sur']}\nВакансия атауы:{data['vacance']}\nСіздің резюмеңіз:{data['resume']}")
	await message.answer('Вакансияға өтініш сәтті қабылданды',reply_markup=kb_client)
	await state.finish()


def register_handlers_client(dp : Dispatcher):
	dp.register_message_handler(command_start,commands=['start','help'])



