import sqlite3 as sq
from create_bot import bot 

def sql_start():
	global base,cur,cur2
	base = sq.connect('vacancies.db')
	cur = base.cursor()
	if base:
		print('Data base connected OK!')
	base.execute('CREATE TABLE IF NOT EXISTS vacancies(img TEXT,name TEXT PRIMARY KEY ,description TEXT,price TEXT,phone TEXT)')
	base.commit()

async def sql_add_command(state):
	async with state.proxy() as data:
		cur.execute('INSERT INTO vacancies VALUES (?, ?, ?, ?, ?)',tuple(data.values()))
		base.commit()

async def sql_read(message):
	for ret in cur.execute('SELECT * FROM vacancies').fetchall():
		await bot.send_message(message.from_user.id,f'Вакансия атауы:{ret[0]}\nВакансия жайлы ақпарат:{ret[2]}\nҚұны:{ret[3]}\nБайланыс номері:{ret[-1]}')
		#await bot.send_photo(message.from_user.id,ret[1],f'{ret[0]}\nАқпарат:{ret[2]}\nМекен-жайы:{ret[3]}\nБайланыс номері:{ret[-1]}')

async def sql_read2():
	return cur.execute('SELECT * FROM vacancies').fetchall()




# async def sql_read2():
# 	return cur.execute('DELETE FROM menu WHERE name == ?',(data,))

