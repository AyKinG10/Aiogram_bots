from aiogram.types import ReplyKeyboardMarkup,KeyboardButton,InlineKeyboardMarkup,InlineKeyboardButton

kb_client = ReplyKeyboardMarkup(resize_keyboard=True)
b1 = KeyboardButton('Бот_туралы📑')
b2 = KeyboardButton('Хабарласу📧')
b3 = KeyboardButton('Вакансиялар✅')
b4 = KeyboardButton('Артқа')
kb_client.add(b3).add(b1).insert(b2).insert(b4)

kb_vac = ReplyKeyboardMarkup(resize_keyboard=True)
bt1 = KeyboardButton('Ұсыныс қалтыру')
bt2 = KeyboardButton('Артқа')
kb_vac.add(bt1,bt2)
