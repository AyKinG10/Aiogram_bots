import sqlite3 as sq
from create_bot import bot 

def sql_start():
	global base,cur
	base = sq.connect('lexus.db')
	cur = base.cursor()
	if base:
		print('Data base connected OK!')
	base.execute('CREATE TABLE IF NOT EXISTS lexus(img TEXT,name TEXT PRIMARY KEY ,description TEXT,price TEXT,year TEXT)')
	base.commit()

async def sql_add_command(state):
	async with state.proxy() as data:
		cur.execute('INSERT INTO lexus VALUES (?, ?, ?, ?, ?)',tuple(data.values()))
		base.commit()

async def sql_read(message):
	for ret in cur.execute('SELECT * FROM lexus').fetchall():
		await bot.send_photo(message.from_user.id,ret[1],f'Lexus {ret[0]}\nХарактеристикасы:{ret[2]}\nБағасы:{ret[3]}\nШыққан жылы:{ret[-1]}')

async def sql_read2():
	return cur.execute('SELECT * FROM lexus').fetchall()




# async def sql_read2():
# 	return cur.execute('DELETE FROM menu WHERE name == ?',(data,))

