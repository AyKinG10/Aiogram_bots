from aiogram import Bot
from aiogram.dispatcher import Dispatcher

from aiogram.contrib.fsm_storage.memory import MemoryStorage

storage = MemoryStorage()

bot = Bot(token="5938798929:AAFduZuKWSCIOJ0PC8LwK1XStiQCrZTueGI")
dp = Dispatcher(bot,storage=storage)