from keyboards.client_kb import kb_client
from keyboards.client_kb import kb_services
from keyboards.client_kb import kb_status
from keyboards.client_kb import kb_shops1
from keyboards.client_kb import kb_shops2
from keyboards.client_kb import kb_shops3
from keyboards.client_kb import kb_shops4
from keyboards.client_kb import kb_sale