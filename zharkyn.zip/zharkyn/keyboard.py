from aiogram.types import KeyboardButton, ReplyKeyboardMarkup, InlineKeyboardMarkup, InlineKeyboardButton
kb = ReplyKeyboardMarkup(resize_keyboard=True)
b2 = KeyboardButton('Біз жайлы')
b3 = KeyboardButton('Автосервис қызметтері')
b4 = KeyboardButton('Онлайн жазылу')
b5 = KeyboardButton('Байланыс')

kb.insert(b2).insert(b3).add(b4).add(b5)

kb_Cars =ReplyKeyboardMarkup(resize_keyboard=True)
bp1=KeyboardButton(text='Toyota')
bp2=KeyboardButton(text='Lexus')
bp3=KeyboardButton(text='Infinity')
bp4=KeyboardButton(text='Lada')
bp5=KeyboardButton(text='Honda')
kb_Cars.add(bp1).insert(bp2).add(bp3).insert(bp4).add(bp5)

kb_Toyota=ReplyKeyboardMarkup(resize_keyboard=True)
bu1=KeyboardButton(text="Camry(XV20-XV70)")
bu2=KeyboardButton(text="Aristo")
bu3=KeyboardButton(text="Avalon")
bu4=KeyboardButton(text="Prius")
bu5=KeyboardButton(text="Alhpard")
bu6=KeyboardButton(text="Corolla")
bu21=KeyboardButton(text="Артқа")
kb_Toyota.add(bu1,bu2,bu3,bu4,bu5,bu6,bu21)


kb_Lexus=ReplyKeyboardMarkup(resize_keyboard=True)
bu7=KeyboardButton(text="LS450")
bu8=KeyboardButton(text="RX300-450")
bu9=KeyboardButton(text="ES250-400")
bu22=KeyboardButton(text="LX470-570")
bu27=KeyboardButton(text="GS250-450")
bu29=KeyboardButton(text="Артқа")

kb_Lexus.add(bu7).insert(bu8).add(bu9).add(bu22).add(bu27).add(bu29)


kb_Infinity=ReplyKeyboardMarkup(resize_keyboard=True)
bu10=KeyboardButton(text="QX56")
bu11=KeyboardButton(text="FX37-45")
bu12=KeyboardButton(text="GX57")
bu13=KeyboardButton(text="SV45")
bu23=KeyboardButton(text="KX35")
bu32=KeyboardButton(text="Артқа")
kb_Infinity.add(bu10,bu11,bu12,bu13,bu23,bu32)


kb_Lada=ReplyKeyboardMarkup(resize_keyboard=True)
bu14=KeyboardButton(text="Priora")
bu15=KeyboardButton(text="Granta")
bu16=KeyboardButton(text="Largus")
bu17=KeyboardButton(text="2114")
bu30=KeyboardButton(text="Vesta")
bu31=KeyboardButton(text="21110")
bu24=KeyboardButton(text="Артқа")
kb_Lada.add(bu14,bu15,bu16,bu17,bu30,bu31,bu24)


kb_Honda=ReplyKeyboardMarkup(resize_keyboard=True)
bu18=KeyboardButton(text="CRV")
bu19=KeyboardButton(text="CIVIC")
bu20=KeyboardButton(text="Oddysey")
bu25=KeyboardButton(text="Accord")
bu33=KeyboardButton(text="NSX")
kb_Honda.add(bu14,bu15,bu16,bu25,bu33,bu24)




