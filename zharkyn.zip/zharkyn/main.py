from aiogram import types,Dispatcher,executor,Bot
from keyboard import kb,kb_Cars,kb_Toyota,kb_Lexus,kb_Infinity,kb_Honda,kb_Lada
from token import TOKEN_API
from aiogram.dispatcher.filters import Text


bot = Bot(TOKEN_API)
dp = Dispatcher(bot)


about_us = """<b>
Сәлем.Бұл Zharkyn көлік жондеу автосервисі.Бұл бот арқылы сіз онлайн машинаныңызды сервиске кіру үшін броньдап койсаныз болады.</em>
<b>Сәттілік!!!</b>"""
contacts="""<b>Егер сіздерде бот бойынша немесе басқа сұрақтар туындаса
Астыда көрсетілген байланыс түрлері арқылы бізбен байланыссаңыздар болады</b>
<b><em>Байланыс нөмірі:</em> +7 777 777 77 77 Жарқын</b>
<b><em>Gmail:</em> Zhareke@gmail.com</b>
<b>Біздің мекен-жай: https://go.2gis.com/6ozx9w</b>"""
zhasyly="""<b>Жазылу үшін +77077077777 хабарласып күнін белгілесеңіз болады.</b>"""
async def on_startup(_):
    print('Бот іске қосылды')


@dp.message_handler(commands=['start'])
async def start_command(message: types.Message):
    await message.answer(text="""<em><b>Саламатсыз ба!Алдыңызда Zharkyn Service автосеривисінің боты.)</b>!
    Керекті командаларды тізімнен таңдаңыз: 🔻</em>""",
                         parse_mode="HTML",
                         reply_markup=kb)
@dp.message_handler(Text(equals="Онлайн жазылу"))
async def city(message:types.Message):
    await message.answer(text=zhasyly,
                         parse_mode="HTML")

@dp.message_handler(Text(equals="Біз жайлы"))
async def city(message:types.Message):
    await message.answer(text=about_us,
                         parse_mode="HTML")

@dp.message_handler(Text(equals="Байланыс"))
async def city(message:types.Message):
    await message.answer(text=contacts,
                         parse_mode="HTML")

@dp.message_handler(Text(equals="Автосервис"))
async def city(message:types.Message):
    await message.answer(text='Астыдағы тізімнен көлігіңізді таңдаңыз:',
                         reply_markup=kb_Cars)

@dp.message_handler(Text(equals="Артқа"))
async def city(message:types.Message):
    await message.answer(text='Керекті команданы таңдаңыз:',
                         reply_markup=kb)

@dp.message_handler(Text(equals="Toyota"))
async def city(message:types.Message):
    await message.answer(text='Модельді таңдаңыз: ',
                         reply_markup=kb_Toyota)

@dp.message_handler(Text(equals="Lexus"))
async def city(message:types.Message):
    await message.answer(text='Модельді таңдаңыз: ',
                         reply_markup=kb_Lexus)

@dp.message_handler(Text(equals="Infinity"))
async def city(message:types.Message):
    await message.answer(text='Модельді таңдаңыз: ',
                         reply_markup=kb_Infinity)
@dp.message_handler(Text(equals="Lada"))
async def city(message:types.Message):
    await message.answer(text='Модельді таңдаңыз: ',
                         reply_markup=kb_Lada)

@dp.message_handler(Text(equals="Honda"))
async def city(message:types.Message):
    await message.answer(text='Модельді таңдаңыз: ',
                         reply_markup=kb_Honda)

@dp.message_handler(Text(equals="Camry(XV20-XV70)"))
async def city(message:types.Message):
    await bot.send_photo(message.chat.id,
                         photo="https://frankfurt.apollo.olxcdn.com/v1/files/qj25k4gh4oiy-KZ/image;s=1600x1000",
                         caption="""<b>Toyota Camry</b>
                         ㅤㅤㅤㅤ<b>Қызметтер:</b><em>
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤҚозғалтқыш майын ауыстыру___ 5000KZT
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤТрансмиссия майын ауыстыру__ 3000KZT
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤХодовка толық диагностика___ 8000KZT
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤСалонды химиялық тазалау____ 15000KZT
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤХодовка ауыстыру____________ 4х=130000KZT 
                         <b>Көлікке толық дагностика(Электрика,Салон,Ходовка)</b>: <em>30 000 теңге </em>
                         <b>Қызметтерга жазылу үшін Онлайын жазылу командасын басыңыз</b>""",
                         parse_mode="HTML")

@dp.message_handler(Text(equals="Alphard"))
async def city(message:types.Message):
    await bot.send_photo(message.chat.id,
                         photo="https://i.pinimg.com/originals/8d/41/d9/8d41d9f20b407d43921713aecae89a6e.jpg",
                         caption="""<b>Toyota Alphard</b>
                        ㅤㅤㅤㅤ<b>Қызметтер:</b><em>
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤҚозғалтқыш майын ауыстыру___ 5000KZT
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤТрансмиссия майын ауыстыру__ 3000KZT
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤХодовка толық диагностика___ 15000KZT
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤСалонды химиялық тазалау____ 25000KZT
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤХодовка ауыстыру____________ 4х=100000KZT 
                         <b>Көлікке толық дагностика(Электрика,Салон,Ходовка)</b>: <em>50000 теңге </em>
                         <b>Қызметтерга жазылу үшін Онлайын жазылу командасын басыңыз</b>""",
                         parse_mode="HTML")

@dp.message_handler(Text(equals="LS450"))
async def city(message: types.Message):
    await bot.send_photo(message.chat.id,
                         photo="https://vieconsciente.com/wp-content/uploads/2019/06/42-New-2019-Toyota-Avalon-Spesification.jpg",
                         caption="""<b>Lexus LS450</b>
                        ㅤㅤㅤㅤ<b>Қызметтер:</b><em>
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤҚозғалтқыш майын ауыстыру___ 10000KZT
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤТрансмиссия майын ауыстыру__ 7000KZT
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤХодовка толық диагностика___ 24000KZT
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤСалонды химиялық тазалау____ 32000KZT
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤХодовка ауыстыру____________ 4х=200000KZT 
                         <b>Көлікке толық дагностика(Электрика,Салон,Ходовка)</b>: <em>60000 теңге </em>
                         <b>Қызметтерга жазылу үшін Онлайын жазылу командасын басыңыз</b>""",
                         parse_mode="HTML")
@dp.message_handler(Text(equals="RX300-450"))
async def city(message:types.Message):
    await bot.send_photo(message.chat.id,
                         photo="https://lexus-cms-media.s3.us-east-2.amazonaws.com/wp-content/uploads/2019/04/2016_Lexus_RX_350_002_2D2AC5AADFE5285DC40C8D05E3DED607A88E1664-1500x900.jpg",
                         caption="""<b>Lexus RX300-450</b>
                        ㅤㅤㅤㅤ<b>Қызметтер:</b><em>
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤҚозғалтқыш майын ауыстыру___ 7000KZT
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤТрансмиссия майын ауыстыру__ 5000KZT
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤХодовка толық диагностика___ 12000KZT
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤСалонды химиялық тазалау____ 25000KZT
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤХодовка ауыстыру____________ 4х=160000KZT 
                         <b>Көлікке толық дагностика(Электрика,Салон,Ходовка)</b>: <em>35000 теңге </em>
                         <b>Қызметтерга жазылу үшін Онлайын жазылу командасын басыңыз</b>""",
                         parse_mode="HTML")
@dp.message_handler(Text(equals="ES250-400"))
async def city(message:types.Message):
    await bot.send_photo(message.chat.id,
                         photo="https://vieconsciente.com/wp-content/uploads/2019/06/42-New-2019-Toyota-Avalon-Spesification.jpg",
                         caption="""<b>Lexus RX300-450</b>
                        ㅤㅤㅤㅤ<b>Қызметтер:</b><em>
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤҚозғалтқыш майын ауыстыру___ 7000KZT
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤТрансмиссия майын ауыстыру__ 5000KZT
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤХодовка толық диагностика___ 12000KZT
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤСалонды химиялық тазалау____ 25000KZT
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤХодовка ауыстыру____________ 4х=160000KZT 
                         <b>Көлікке толық дагностика(Электрика,Салон,Ходовка)</b>: <em>35000 теңге </em>
                         <b>Қызметтерга жазылу үшін Онлайын жазылу командасын басыңыз</b>""",
                         parse_mode="HTML")
@dp.message_handler(Text(equals="QX56"))
async def city(message:types.Message):
    await bot.send_photo(message.chat.id,
                         photo="https://wroom.ru/i2/carpic/26423.jpg",
                         caption="""<b>Infinity QX65</b>
                        ㅤㅤㅤㅤ<b>Қызметтер:</b><em>
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤҚозғалтқыш майын ауыстыру___ 5000KZT
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤТрансмиссия майын ауыстыру__ 3000KZT
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤХодовка толық диагностика___ 10000KZT
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤСалонды химиялық тазалау____ 23000KZT
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤХодовка ауыстыру____________ 4х=160000KZT 
                         <b>Көлікке толық дагностика(Электрика,Салон,Ходовка)</b>: <em>45000 теңге </em>
                         <b>Қызметтерга жазылу үшін Онлайын жазылу командасын басыңыз</b>""",
                         parse_mode="HTML")
@dp.message_handler(Text(equals="FX37-45"))
async def city(message:types.Message):
    await bot.send_photo(message.chat.id,
                         photo="https://taldom-gorod.ru/800/600/https/oir.mobi/uploads/posts/2020-01/1578228395_47-65.jpg",
                         caption="""<b>Infinity FX</b>
                        ㅤㅤㅤㅤ<b>Қызметтер:</b><em>
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤҚозғалтқыш майын ауыстыру___ 5000KZT
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤТрансмиссия майын ауыстыру__ 3000KZT
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤХодовка толық диагностика___ 10000KZT
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤСалонды химиялық тазалау____ 23000KZT
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤХодовка ауыстыру____________ 4х=160000KZT 
                         <b>Көлікке толық дагностика(Электрика,Салон,Ходовка)</b>: <em>45000 теңге </em>
                         <b>Қызметтерга жазылу үшін Онлайын жазылу командасын басыңыз</b>""",
                         parse_mode="HTML")
@dp.message_handler(Text(equals="GX57"))
async def city(message:types.Message):
    await bot.send_photo(message.chat.id,
                         photo="https://avtobak.net/wp-content/uploads/2017/03/infiniti-fx45-1.jpg",
                         caption="""<b>Infinity GX</b>
                        ㅤㅤㅤㅤ<b>Қызметтер:</b><em>
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤҚозғалтқыш майын ауыстыру___ 5000KZT
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤТрансмиссия майын ауыстыру__ 3000KZT
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤХодовка толық диагностика___ 10000KZT
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤСалонды химиялық тазалау____ 23000KZT
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤХодовка ауыстыру____________ 4х=160000KZT 
                         <b>Көлікке толық дагностика(Электрика,Салон,Ходовка)</b>: <em>45000 теңге </em>
                         <b>Қызметтерга жазылу үшін Онлайын жазылу командасын басыңыз</b>""",
                         parse_mode="HTML")
@dp.message_handler(Text(equals="Priora"))
async def city(message:types.Message):
    await bot.send_photo(message.chat.id,
                         photo="https://otvetic.ru/wp-content/uploads/2022/04/2-5.jpg",
                         caption="""<b>Lada Priora</b>
                        ㅤㅤㅤㅤ<b>Қызметтер:</b><em>
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤҚозғалтқыш майын ауыстыру___ 3000KZT
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤТрансмиссия майын ауыстыру__ 2500KZT
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤХодовка толық диагностика___ 6000KZT
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤСалонды химиялық тазалау____ 15000KZT
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤХодовка ауыстыру____________ 4х=50000KZT 
                         <b>Көлікке толық дагностика(Электрика,Салон,Ходовка)</b>: <em>30000 теңге </em>
                         <b>Қызметтерга жазылу үшін Онлайын жазылу командасын басыңыз</b>""",
                         parse_mode="HTML")
@dp.message_handler(Text(equals="Largus"))
async def city(message:types.Message):
    await bot.send_photo(message.chat.id,
                         photo="https://pbs.twimg.com/media/Cchh8HSW4AAQ6UE.jpg:large",
                         caption="""<b>Lada Largus</b>
                        ㅤㅤㅤㅤ<b>Қызметтер:</b><em>
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤҚозғалтқыш майын ауыстыру___ 3000KZT
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤТрансмиссия майын ауыстыру__ 2500KZT
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤХодовка толық диагностика___ 6000KZT
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤСалонды химиялық тазалау____ 15000KZT
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤХодовка ауыстыру____________ 4х=50000KZT 
                         <b>Көлікке толық дагностика(Электрика,Салон,Ходовка)</b>: <em>30000 теңге </em>
                         <b>Қызметтерга жазылу үшін Онлайын жазылу командасын басыңыз</b>""",
                         parse_mode="HTML")
@dp.message_handler(Text(equals="Granta"))
async def city(message:types.Message):
    await bot.send_photo(message.chat.id,
                         photo="https://avtoshark.com/wp-content/uploads/2022/08/lada-granta-2019-goda.jpg",
                         caption="""<b>Lada Granta</b>
                        ㅤㅤㅤㅤ<b>Қызметтер:</b><em>
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤҚозғалтқыш майын ауыстыру___ 3000KZT
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤТрансмиссия майын ауыстыру__ 2500KZT
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤХодовка толық диагностика___ 6000KZT
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤСалонды химиялық тазалау____ 15000KZT
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤХодовка ауыстыру____________ 4х=50000KZT 
                         <b>Көлікке толық дагностика(Электрика,Салон,Ходовка)</b>: <em>30000 теңге </em>
                         <b>Қызметтерга жазылу үшін Онлайын жазылу командасын басыңыз</b>""",
                         parse_mode="HTML")


@dp.message_handler(Text(equals="CRV"))
async def city(message:types.Message):
    await bot.send_photo(message.chat.id,
                         photo="https://i.cenyavto.com/2019/04/2a8c57f0d41ef292dea01904e84054f9.jpeg",
                         caption="""<b>Honda CRV</b>
                        ㅤㅤㅤㅤ<b>Қызметтер:</b><em>
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤҚозғалтқыш майын ауыстыру___ 4000KZT
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤТрансмиссия майын ауыстыру__ 3000KZT
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤХодовка толық диагностика___ 7000KZT
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤСалонды химиялық тазалау____ 12000KZT
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤХодовка ауыстыру____________ 4х=60000KZT 
                         <b>Көлікке толық дагностика(Электрика,Салон,Ходовка)</b>: <em>30000 теңге </em>
                         <b>Қызметтерга жазылу үшін Онлайын жазылу командасын басыңыз</b>""",
                         parse_mode="HTML")
@dp.message_handler(Text(equals="CIVIC"))
async def city(message:types.Message):
    await bot.send_photo(message.chat.id,
                         photo="https://cool-shina.ru/wp-content/uploads/b/7/4/b74ca92a357318fa250c043bfe9f8808.jpeg",
                         caption="""<b>Honda Civic</b>
                        ㅤㅤㅤㅤ<b>Қызметтер:</b><em>
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤҚозғалтқыш майын ауыстыру___ 4000KZT
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤТрансмиссия майын ауыстыру__ 300KZT
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤХодовка толық диагностика___ 8000KZT
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤСалонды химиялық тазалау____ 18000KZT
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤХодовка ауыстыру____________ 4х=80000KZT 
                         <b>Көлікке толық дагностика(Электрика,Салон,Ходовка)</b>: <em>40000 теңге </em>
                         <b>Қызметтерга жазылу үшін Онлайын жазылу командасын басыңыз</b>""",
                         parse_mode="HTML")
@dp.message_handler(Text(equals="Oddysey"))
async def city(message:types.Message):
    await bot.send_photo(message.chat.id,
                         photo="https://gaspoint.kz/img/honda/Odyssey.jpg",
                         caption="""<b>Honda Oddysey</b>
                        ㅤㅤㅤㅤ<b>Қызметтер:</b><em>
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤҚозғалтқыш майын ауыстыру___ 3500KZT
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤТрансмиссия майын ауыстыру__ 300KZT
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤХодовка толық диагностика___ 7000KZT
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤСалонды химиялық тазалау____ 15000KZT
                         ㅤㅤㅤㅤㅤㅤㅤㅤㅤХодовка ауыстыру____________ 4х=50000KZT 
                         <b>Көлікке толық дагностика(Электрика,Салон,Ходовка)</b>: <em>36000 теңге </em>
                         <b>Қызметтерга жазылу үшін Онлайын жазылу командасын басыңыз</b>""",
                         parse_mode="HTML")


if __name__ == '__main__':
    executor.start_polling(dp,on_startup=on_startup,skip_updates=True)